Python ISO and ASCII To UTF-8
===============

Simple python script that converts all files in the given path from iso-8859-1 or ascii to UTF-8


USAGE:
------

just run:

    ./go2utf8.py path_to_some_dir

this will create a directory called **converted** that will have all the files from path_to_some_dir inside and converted.

This script was basically based on *Sébastien RoccaSerra* answer on StackOverflow:
http://stackoverflow.com/a/192086/680611

